<?php
/**
 * Tools tab view for the MCP Tools for Elementor admin settings page.
 *
 * Displays all MCP tools grouped by category with toggle switches.
 *
 * @package EMCP_Tools
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var EMCP_Tools_Admin $this */
$emcp_tools_all_tools     = $this->get_all_tools();
$emcp_tools_disabled      = get_option( EMCP_Tools_Admin::OPTION_DISABLED_TOOLS, array() );
$emcp_tools_enabled_count = $this->get_enabled_tool_count();
$emcp_tools_total_count   = $this->get_total_tool_count();
$emcp_tools_low_mode      = '1' === (string) get_option( EMCP_Tools_Admin::OPTION_LOW_TOOL_MODE, '0' );
?>

<form method="post" action="options.php" id="elementor-mcp-tools-form">
	<?php settings_fields( EMCP_Tools_Admin::SETTINGS_GROUP ); ?>

	<div class="elementor-mcp-low-mode-card">
		<label class="elementor-mcp-low-mode-toggle">
			<input type="hidden" name="<?php echo esc_attr( EMCP_Tools_Admin::OPTION_LOW_TOOL_MODE ); ?>" value="0" />
			<input
				type="checkbox"
				name="<?php echo esc_attr( EMCP_Tools_Admin::OPTION_LOW_TOOL_MODE ); ?>"
				value="1"
				<?php checked( $emcp_tools_low_mode ); ?>
			/>
			<span class="elementor-mcp-toggle" aria-hidden="true">
				<span class="elementor-mcp-toggle-track"></span>
			</span>
			<span class="elementor-mcp-low-mode-info">
				<span class="elementor-mcp-low-mode-title">
					<?php esc_html_e( 'Low-tools mode (Antigravity-friendly)', 'emcp-tools' ); ?>
				</span>
				<span class="elementor-mcp-low-mode-desc">
					<?php esc_html_e( 'Keeps the active tool count under 60 by exposing only a curated set of essential abilities. Use this when your MCP client enforces a strict tool cap. Your individual toggles below are preserved and take effect again when this is turned off.', 'emcp-tools' ); ?>
				</span>
			</span>
		</label>
	</div>

	<p class="elementor-mcp-tools-summary">
		<?php
		printf(
			/* translators: %1$s: opening strong tag, %2$d: enabled count, %3$d: total count, %4$s: closing strong tag */
			esc_html__( '%1$s%2$d of %3$d%4$s tools enabled.', 'emcp-tools' ),
			'<strong>',
			(int) $emcp_tools_enabled_count,
			(int) $emcp_tools_total_count,
			'</strong>'
		);
		?>
	</p>

	<div class="elementor-mcp-bulk-actions">
		<button type="button" class="button elementor-mcp-enable-all"><?php esc_html_e( 'Enable All', 'emcp-tools' ); ?></button>
		<button type="button" class="button elementor-mcp-disable-all"><?php esc_html_e( 'Disable All', 'emcp-tools' ); ?></button>
		<button type="submit" class="button button-primary elementor-mcp-bulk-save"><?php esc_html_e( 'Save Changes', 'emcp-tools' ); ?></button>
	</div>

	<?php foreach ( $emcp_tools_all_tools as $emcp_tools_category_id => $emcp_tools_category ) : ?>
		<div class="elementor-mcp-category" data-category="<?php echo esc_attr( $emcp_tools_category_id ); ?>">
			<h2 class="elementor-mcp-category-header">
				<?php echo esc_html( $emcp_tools_category['label'] ); ?>
				<span class="elementor-mcp-category-count">
					<?php
					$emcp_tools_cat_total   = count( $emcp_tools_category['tools'] );
					$emcp_tools_cat_enabled = 0;
					foreach ( $emcp_tools_category['tools'] as $emcp_tools_slug => $emcp_tools_tool ) {
						if ( ! in_array( $emcp_tools_slug, $emcp_tools_disabled, true ) ) {
							$emcp_tools_cat_enabled++;
						}
					}
					printf(
						/* translators: %1$d: enabled, %2$d: total */
						esc_html__( '%1$d / %2$d', 'emcp-tools' ),
						(int) $emcp_tools_cat_enabled,
						(int) $emcp_tools_cat_total
					);
					?>
				</span>
				<span class="elementor-mcp-category-actions">
					<button type="button" class="button-link elementor-mcp-cat-enable-all"><?php esc_html_e( 'All', 'emcp-tools' ); ?></button>
					<span class="elementor-mcp-separator">&middot;</span>
					<button type="button" class="button-link elementor-mcp-cat-disable-all"><?php esc_html_e( 'None', 'emcp-tools' ); ?></button>
				</span>
			</h2>

			<div class="elementor-mcp-tools-grid">
				<?php foreach ( $emcp_tools_category['tools'] as $emcp_tools_slug => $emcp_tools_tool ) : ?>
					<?php $emcp_tools_is_enabled = ! in_array( $emcp_tools_slug, $emcp_tools_disabled, true ); ?>
					<label class="elementor-mcp-tool-card <?php echo esc_attr( $emcp_tools_is_enabled ? 'is-enabled' : 'is-disabled' ); ?>">
						<input
							type="checkbox"
							name="<?php echo esc_attr( EMCP_Tools_Admin::OPTION_DISABLED_TOOLS ); ?>[]"
							value="<?php echo esc_attr( $emcp_tools_slug ); ?>"
							<?php checked( $emcp_tools_is_enabled ); ?>
						/>
						<span class="elementor-mcp-toggle" aria-hidden="true">
							<span class="elementor-mcp-toggle-track"></span>
						</span>
						<span class="elementor-mcp-tool-info">
							<span class="elementor-mcp-tool-name">
								<?php echo esc_html( $emcp_tools_tool['label'] ); ?>
								<?php foreach ( $emcp_tools_tool['badges'] as $emcp_tools_badge ) : ?>
									<span class="elementor-mcp-badge elementor-mcp-badge--<?php echo esc_attr( $emcp_tools_badge ); ?>">
										<?php echo esc_html( $emcp_tools_badge ); ?>
									</span>
								<?php endforeach; ?>
							</span>
							<span class="elementor-mcp-tool-desc"><?php echo esc_html( $emcp_tools_tool['description'] ); ?></span>
							<code class="elementor-mcp-tool-slug"><?php echo esc_html( $emcp_tools_slug ); ?></code>
						</span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endforeach; ?>

	<?php submit_button( __( 'Save Changes', 'emcp-tools' ) ); ?>
</form>
